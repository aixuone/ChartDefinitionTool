CREATE VIEW v_resource_parameter AS (SELECT
                                       m.META_PK         pk,
                                       m.META_ID         id,
                                       m.META_NAME       name,
                                       m.META_SYSTEM     system,
                                       m.META_DESC       describ,
                                       m.META_REMARK     remark,
                                       m.META_STATUS     status,
                                       m.META_UPDATE     upddate,
                                       m.META_UPDTIME    updtime,
                                       p.PARA_PK         ppk,
                                       p.PARA_KEY        pkey,
                                       p.PARA_VALUE      value,
                                       p.PARA_PARAMETER1 data1,
                                       p.PARA_PARAMETER2 data2,
                                       p.PARA_PARAMETER3 data3,
                                       p.PARA_REMARK     premark
                                     FROM T_META_MANAGE
                                          m,
                                       T_META_PARAMETER p
                                     WHERE m
                                           .META_PK = p.META_PK AND m.META_TYPE = 'PARAMETER')